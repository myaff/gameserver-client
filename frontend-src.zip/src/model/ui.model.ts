export interface UiAlert {
  title: string;
  message?: string;
  icon?: string;
  type?: string;
}